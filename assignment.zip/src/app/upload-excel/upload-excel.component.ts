import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-excel',
  templateUrl: './upload-excel.component.html',
  styleUrls: ['./upload-excel.component.css']
})
export class UploadExcelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  uploadedFiles: File[] = [];

  onFilesSelected(event: any) {
    const files = event.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        this.uploadedFiles.push(files[i]);
        console.log(files[i]);
      }
    }
  }

}
